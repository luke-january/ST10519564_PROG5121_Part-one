
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp1;

/**
 *
 * @author Student
 */

//---------------------------------------
// These are the only imports we do for JUnit 5 testing
//--------------------------------------
import org.junit.jupiter.api.Test;
// This allows us to write @Test above a method
// @Test tells NetBeans that this is a unit test

import static org.junit.jupiter.api.Assertions.*;
// This import gives us access to "assertEquals", "assertTrue", "assertFalse".
// We use these to CHECK whether the code gives the correct output.

public class LoginTest {
    
    // Creating an object to test the method
    Login login = new Login();
    
    //========================================
    //           USERNAME TESTS
    //========================================
    
    @Test
    public void testInvalidUsernameMessage() {
        /*
        The purpose of the test:
        We provide an INCORRECT username "Kyle!!!!!!".
        We expect registerUser() to return the correct ERROR MESSAGE.
        This matches the test data given in the POE.     
        */
        
        String result = login.registerUser("Kyle!!!!!","Ch&&sec@ke99!","+27838968976");
        
        // assertEquals checks if the actual result is EXACTLY the same as expected.
        assertEquals(
            "Username is not currently formatted please ensure that your username contains an underscore and is no much more than five character in length",
            result
        );
    }
    
    @Test
    public void testInvalidUsernameMessageBoolean() {
        // This test checks that an invalid username returns FALSE
        assertFalse(login.checkUserName("Kyle!!!!!"));
    }
    
    @Test
    public void testValidUsernameMessageBoolean() {
        // This test checks that a valid username returns TRUE
        assertTrue(login.checkUserName("Kyl_l"));
    }
    
    @Test
    public void testValidPasswordMessageBoolean() {
        // This test checks that a valid password returns TRUE
        assertTrue(login.checkPassword("Ch&&sec@ke99!"));
    }
    
    @Test
    public void testInValidPasswordMessageBoolean() {
        // This test checks that an invalid password returns FALSE
        assertFalse(login.checkPassword("Password"));   
    }
    
    @Test
    public void testValidPhoneNumberMessageBoolean() {
        // This test checks that a valid phone number returns TRUE
        assertTrue(login.checkPhoneNumber("+27838968976"));
    }  
    
    @Test
    public void testInValidPhoneNumberMessageBoolean() {
        // This test checks that an invalid phone number returns FALSE
        assertFalse(login.checkPhoneNumber("08966553"));  
    }
}