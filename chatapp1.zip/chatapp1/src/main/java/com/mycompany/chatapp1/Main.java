/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp1;

import java.util.Scanner;

/**
 *
 * @author Student
 */

// Package name may differ depending on NetBeans setup

public class Main {
    public static void main(String[] args) {
        
        // Scanner allows the user to enter info
        Scanner input = new Scanner(System.in);
        
        // Create an object of the Login class
        Login login = new Login();
        
        // --- REGISTRATION ---
        System.out.println("=== USER REGISTRATION ===");
        
        System.out.print("Enter username: ");
        String username = input.nextLine();
        
        System.out.print("Enter password: ");
        String password = input.nextLine();
            
        System.out.print("Enter your South African phone number (+27...): ");
        String phone = input.nextLine();
        
        // Call registerUser and save the message as it returns
        String response = login.registerUser(username, password, phone);
        
        // Show the registration message
        System.out.println(response);
        
        // --- LOGIN SECTION ---
        System.out.println("\n=== USER LOGIN ===");
        
        System.out.println("Enter your username:");
        String loginUsername = input.nextLine();
        
        System.out.println("Enter your password:");
        String loginPassword = input.nextLine();
        
        // Call loginUser to check if details match the stored ones
        boolean loggedIn = login.loginUser(loginUsername, loginPassword);
                 
        // Print out the right login message
        String loginMessage = login.returnLoginStatus(loggedIn);
        System.out.println(loginMessage);
    }
}
 
           
