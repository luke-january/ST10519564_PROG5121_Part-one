/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp1;

/**
 *
 * @author Student
 */

public class Login {

    String Password;
    String PhoneNumber;
    String UserName;

    // Check if username contains underscore and is no more than 5 characters
    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Check password complexity
    public boolean checkPassword(String password) {

        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;

        for (int i = 0; i < password.length(); i++) {
            char c = password.charAt(i);

            if (Character.isUpperCase(c)) {
                hasCapital = true;
            } else if (Character.isDigit(c)) {
                hasNumber = true;
            } else if (!Character.isLetterOrDigit(c)) {
                hasSpecial = true;
            }
        }

        return password.length() >= 8 && hasCapital && hasNumber && hasSpecial;
    }

    // Check South African phone number format
    public boolean checkPhoneNumber(String phone) {
        return phone.startsWith("+27") && phone.length() == 12;
    }

    // Register user
    public String registerUser(String username, String password, String phoneNumber) {

        if (!checkUserName(username)) {
            return "Username is not currently formatted please ensure that your username contains an underscore and is no much more than five character in length";
        }

        if (!checkPassword(password)) {
            return "Password is not correctly formatted";
        }

        if (!checkPhoneNumber(phoneNumber)) {
            return "Phone number incorrectly formatted or does not contain international code.";
        }

        this.UserName = username;
        this.Password = password;
        this.PhoneNumber = phoneNumber;

        return "User has been registered successfully";
    }

    // Login verification
    public boolean loginUser(String username, String password) {
        return this.UserName != null &&
               this.UserName.equals(username) &&
               this.Password.equals(password);
    }

    // Login status message
    public String returnLoginStatus(boolean success) {
        if (success) {
            return "Welcome " + UserName + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again";
        }
    }
}